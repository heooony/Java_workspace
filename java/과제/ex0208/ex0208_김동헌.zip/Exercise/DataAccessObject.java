package exercise08_interface;

public interface DataAccessObject {
	void select();
	void insert();
	void update();
	void delete();
}
