package driver_example;

public class DriverExample {
	public static void main(String[] args) {
		Driver driver = new Driver();
		
		Bus bus = new Bus();
		Taxi taxi = new Taxi();
		
		driver.drive(bus);
		driver.drive(taxi);
		
		Vehicle vehicle = new Bus();
		
//		����Ÿ�Ժ�ȯ Ȯ�� �κ�
//		vehicle.run();
//		//vehicle.checkFare();
//		
//		Bus bus = (Bus) vehicle;
//		bus.run();
//		bus.checkFare();
	}
}
