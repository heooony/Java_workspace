package child_interface;

public interface ChildInterface1 extends ParentInterface {
	public void method3();
}
