package driver_example;

public interface Vehicle {
	public void run();
}
