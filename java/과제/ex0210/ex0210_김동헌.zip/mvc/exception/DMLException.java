package mvc.exception;

public class DMLException extends Exception {
	public DMLException() {}
	public DMLException(String message) {
		super(message);
	}
}