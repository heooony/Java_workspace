package exercise08_interface;

interface Action {
	void work();
}
