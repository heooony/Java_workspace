package child_interface;

public interface ChildInterface3 extends ParentInterface {
	@Override
	public void method2();
	public void method3();
}
