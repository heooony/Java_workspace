package remote_control;

public interface Searchable {
	void search(String url);
}
