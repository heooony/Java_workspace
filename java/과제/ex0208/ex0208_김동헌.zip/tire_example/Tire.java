package tire_example;

public interface Tire {
	public void roll();
}
